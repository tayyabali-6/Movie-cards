let obj = [
    { imgurl: "https://m.media-amazon.com/images/M/MV5BMTI1NDMyMjExOF5BMl5BanBnXkFtZTcwOTc4MjQzMQ@@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Goblet of Fire" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BNGJhM2M2MWYtZjIzMC00MDZmLThkY2EtOWViMDhhYjRhMzk4XkEyXkFqcGc@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Chamber of Secrets" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BOTA1Mzc2N2ItZWRiNS00MjQzLTlmZDQtMjU0NmY1YWRkMGQ4XkEyXkFqcGc@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Deathly Hallows: Part 2" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BYWJmM2M1YzItMjY1Ni00YzRmLTg5YWYtNDFmNTJjNzQ0ODkyXkEyXkFqcGc@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Order of the Phoenix" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BMTY4NTIwODg0N15BMl5BanBnXkFtZTcwOTc0MjEzMw@@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Prisoner of Azkaban" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BNzU3NDg4NTAyNV5BMl5BanBnXkFtZTcwOTg2ODg1Mg@@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Half-Blood Prince" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BNTU1MzgyMDMtMzBlZS00YzczLThmYWEtMjU3YmFlOWEyMjE1XkEyXkFqcGc@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Sorcerer's Stone" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BMTQ2OTE1Mjk0N15BMl5BanBnXkFtZTcwODE3MDAwNA@@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"Harry Potter and the Deathly Hallows: Part 1" },
    { imgurl: "https://m.media-amazon.com/images/M/MV5BMjE0ODEwNjM2NF5BMl5BanBnXkFtZTcwMjU2Mzg3NA@@._V1_SX300.jpg", heart: "<i class='ri-heart-line'></i>", name:"When Harry Met Sally..." },
];

let cards = ''
obj.forEach((element, index) => {
    cards += `
    <div class="col-lg-3 col-md-4 col-sm-12 mt-5 col-card" >
        <div class="card">
            <img src="${element.imgurl}" id="${index}">
            <div class="content">
                <h4 style="margin-left: 10px;">2011</h4>
                <span>
                    <p>${element.heart}</p>
                    <h4>${element.name}</h4>
                </span>
            </div>
        </div>
    </div>
    `
});
document.getElementById('row').innerHTML = cards

let overlay = document.querySelector('.overlay')
let cardImg = document.querySelectorAll('.col-card')
let overlayImg = document.querySelector('.overlay img')

cardImg.forEach((item) => {
    item.addEventListener('click', function () {
        overlay.style.display = 'block'
        let img= item.querySelector('img').id
        overlayImg.src = obj[img].imgurl
    })
});

document.getElementById('cros').onclick = function(){
    overlay.style.display = 'none'

}